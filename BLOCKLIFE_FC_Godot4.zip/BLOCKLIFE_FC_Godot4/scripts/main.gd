extends Control

var content: VBoxContainer
var status_label: Label
var search_box: LineEdit
const BG := Color("#08121f")
const PANEL := Color("#122236")
const ACCENT := Color("#7cf0b2")
const MUTED := Color("#a8b8ca")

func _ready() -> void:
    _build_shell()
    show_page("home")

func _build_shell() -> void:
    set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    var bg := ColorRect.new()
    bg.color = BG
    bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(bg)
    var margin := MarginContainer.new()
    margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    margin.add_theme_constant_override("margin_left", 24)
    margin.add_theme_constant_override("margin_right", 24)
    margin.add_theme_constant_override("margin_top", 18)
    margin.add_theme_constant_override("margin_bottom", 18)
    add_child(margin)
    var layout := VBoxContainer.new()
    layout.add_theme_constant_override("separation", 10)
    margin.add_child(layout)
    var header := HBoxContainer.new()
    layout.add_child(header)
    var logo := Label.new()
    logo.text = "BLOCKLIFE FC"
    logo.add_theme_font_size_override("font_size", 28)
    logo.add_theme_color_override("font_color", ACCENT)
    header.add_child(logo)
    var spacer := Control.new()
    spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    header.add_child(spacer)
    var date := Label.new()
    date.text = "SEASON %d  •  %s" % [GameState.season, GameState.current_date]
    date.add_theme_color_override("font_color", MUTED)
    header.add_child(date)
    var nav := HBoxContainer.new()
    nav.add_theme_constant_override("separation", 6)
    layout.add_child(nav)
    var pages := [["Home","home"],["Career","career"],["Calendar","calendar"],["Squad","squad"],["Transfer Centre","transfers"],["Competitions","competitions"],["Save","save"],["Load","load"]]
    for item in pages:
        var b := Button.new()
        b.text = item[0]
        _style_button(b, false)
        b.pressed.connect(_navigate.bind(item[1]))
        nav.add_child(b)
    layout.add_child(HSeparator.new())
    var scroll := ScrollContainer.new()
    scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
    layout.add_child(scroll)
    content = VBoxContainer.new()
    content.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    content.add_theme_constant_override("separation", 12)
    scroll.add_child(content)
    status_label = Label.new()
    status_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    status_label.add_theme_color_override("font_color", ACCENT)
    layout.add_child(status_label)

func _navigate(page: String) -> void:
    if page == "save":
        GameState.save_game()
        status_label.text = GameState.notification
    elif page == "load":
        GameState.load_game()
        show_page("home")
    else:
        show_page(page)

func show_page(page: String) -> void:
    for child in content.get_children():
        child.queue_free()
    match page:
        "home": _show_home()
        "career": _show_career()
        "calendar": _show_calendar()
        "squad": _show_squad()
        "transfers": _show_transfers()
        "competitions": _show_competitions()
        _: _show_home()
    status_label.text = GameState.notification

func _heading(title: String, subtitle: String = "") -> void:
    var h := Label.new()
    h.text = title
    h.add_theme_font_size_override("font_size", 24)
    h.add_theme_color_override("font_color", Color.WHITE)
    content.add_child(h)
    if subtitle != "":
        var s := Label.new()
        s.text = subtitle
        s.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
        s.add_theme_color_override("font_color", MUTED)
        content.add_child(s)

func _panel(title: String) -> VBoxContainer:
    var outer := PanelContainer.new()
    var style := StyleBoxFlat.new()
    style.bg_color = PANEL
    style.set_corner_radius_all(10)
    style.content_margin_left = 14
    style.content_margin_right = 14
    style.content_margin_top = 12
    style.content_margin_bottom = 12
    outer.add_theme_stylebox_override("panel", style)
    content.add_child(outer)
    var box := VBoxContainer.new()
    box.add_theme_constant_override("separation", 8)
    outer.add_child(box)
    var label := Label.new()
    label.text = title
    label.add_theme_font_size_override("font_size", 17)
    label.add_theme_color_override("font_color", ACCENT)
    box.add_child(label)
    return box

func _style_button(b: Button, primary: bool) -> void:
    b.add_theme_color_override("font_color", Color("#07131c") if primary else Color.WHITE)
    b.add_theme_stylebox_override("normal", _button_style(ACCENT if primary else Color("#24384e")))
    b.add_theme_stylebox_override("hover", _button_style(Color("#9ff6c7") if primary else Color("#344c65")))
    b.add_theme_stylebox_override("pressed", _button_style(Color("#52d894")))

func _button_style(color: Color) -> StyleBoxFlat:
    var s := StyleBoxFlat.new()
    s.bg_color = color
    s.set_corner_radius_all(7)
    s.content_margin_left = 10
    s.content_margin_right = 10
    s.content_margin_top = 6
    s.content_margin_bottom = 6
    return s

func _button(parent: Node, text_value: String, action: Callable, primary: bool = false) -> Button:
    var b := Button.new()
    b.text = text_value
    _style_button(b, primary)
    b.pressed.connect(action)
    parent.add_child(b)
    return b

func _text(parent: Node, value: String) -> void:
    var l := Label.new()
    l.text = value
    l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    l.add_theme_color_override("font_color", Color("#e3edf7"))
    parent.add_child(l)

func _show_home() -> void:
    _heading("BUILD YOUR FOOTBALL LEGACY", "A native Godot 4 career-simulation foundation: choose a mode, manage your squad, simulate fixtures, and make transfers.")
    var panel := _panel("CAREER OVERVIEW")
    var club := GameState.get_user_club()
    var squad := GameState.get_squad()
    var total := 0
    for p in squad:
        total += int(p.get("ovr", 0))
    var average := float(total) / float(squad.size()) if not squad.is_empty() else 0.0
    _text(panel, "Club: %s  |  Budget: €%s  |  Squad: %d  |  Average OVR: %.1f" % [club.get("name","Unknown"), _money(int(club.get("budget",0))), squad.size(), average])
    var row := HBoxContainer.new()
    panel.add_child(row)
    _button(row, "PLAYER CAREER", func(): _choose_mode("Player Career"))
    _button(row, "MANAGER CAREER", func(): _choose_mode("Manager Career"), true)
    _button(panel, "Open Career Hub", func(): show_page("career"), true)
    var actions := _panel("QUICK ACTIONS")
    var action_row := HBoxContainer.new()
    actions.add_child(action_row)
    _button(action_row, "Calendar", func(): show_page("calendar"))
    _button(action_row, "Squad", func(): show_page("squad"))
    _button(action_row, "Transfer Centre", func(): show_page("transfers"))
    _button(action_row, "Simulate Next Fixture", _simulate_next, true)
    _text(actions, "Starter data note: real-player names are included, but ratings, values, ages and club assignments are estimates, not a verified live roster. Match results are simulated; 3D match gameplay is not implemented yet.")

func _choose_mode(mode: String) -> void:
    GameState.career_mode = mode
    if mode == "Player Career" and GameState.created_player.is_empty():
        GameState.created_player = {"id":"created_player_001","name":"Your Player","age":18,"nationality":"UAE","position":"ST","foot":"Right","shirt_number":9,"ovr":65,"potential":88,"club_id":GameState.user_club_id,"xp":0,"goals":0,"assists":0,"appearances":0,"contract_years":3}
    GameState.notification = mode + " selected."
    GameState.save_game()
    show_page("career")

func _show_career() -> void:
    _heading(GameState.career_mode.to_upper(), "Season %d • %s • shared club and player database" % [GameState.season, GameState.current_date])
    var panel := _panel("CAREER DASHBOARD")
    _text(panel, "Club: %s" % GameState.get_user_club().get("name", "Unknown"))
    if GameState.career_mode == "Player Career":
        if GameState.created_player.is_empty():
            GameState.created_player = {"id":"created_player_001","name":"Your Player","age":18,"nationality":"UAE","position":"ST","foot":"Right","shirt_number":9,"ovr":65,"potential":88,"club_id":GameState.user_club_id,"xp":0,"goals":0,"assists":0,"appearances":0,"contract_years":3}
        var p: Dictionary = GameState.created_player
        _text(panel, "%s • %s • OVR %d / POT %d • Goals %d • Assists %d • Contract %d years" % [p.get("name","Your Player"),p.get("position","ST"),int(p.get("ovr",65)),int(p.get("potential",88)),int(p.get("goals",0)),int(p.get("assists",0)),int(p.get("contract_years",3))])
        _button(panel, "Train player (+1 OVR)", _train_player, true)
    else:
        _text(panel, "Manager career: oversee %d first-team players, club budget, results and transfers." % GameState.get_squad().size())
        _button(panel, "Manage squad", func(): show_page("squad"), true)
    _button(panel, "Advance date by 7 days", _advance_week)
    _button(panel, "Save career", _save_and_refresh)

func _save_and_refresh() -> void:
    GameState.save_game()
    status_label.text = GameState.notification

func _train_player() -> void:
    var p: Dictionary = GameState.created_player
    if p.is_empty():
        return
    var current := int(p.get("ovr", 65))
    var potential := int(p.get("potential", 88))
    if current >= potential:
        GameState.notification = "Your player has reached their potential."
    else:
        p["ovr"] = min(current + 1, potential)
        p["xp"] = int(p.get("xp", 0)) + 25
        GameState.created_player = p
        GameState.notification = "Training complete. OVR is now %d." % int(p["ovr"])
        GameState.save_game()
    show_page("career")

func _advance_week() -> void:
    var stamp := Time.get_unix_time_from_datetime_string(GameState.current_date + "T00:00:00") + 604800
    var next := Time.get_datetime_dict_from_unix_time(stamp)
    GameState.current_date = "%04d-%02d-%02d" % [next.year, next.month, next.day]
    GameState.notification = "Calendar advanced to " + GameState.current_date
    GameState.save_game()
    show_page("career")

func _show_calendar() -> void:
    _heading("SEASON CALENDAR", "Sample fixtures. Simulating a result updates the points table and save data.")
    var panel := _panel("FIXTURE LIST")
    for f in GameState.fixtures:
        var row := HBoxContainer.new()
        panel.add_child(row)
        var home := GameState.get_club(str(f.get("home_club_id","")))
        var away := GameState.get_club(str(f.get("away_club_id","")))
        var result := "UPCOMING"
        if str(f.get("status","")) == "Played":
            result = "%d - %d" % [int(f.get("home_score",0)), int(f.get("away_score",0))]
        var l := Label.new()
        l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
        l.text = "%s • %s • %s vs %s • %s" % [f.get("date",""),f.get("competition",""),home.get("name","TBC"),away.get("name","TBC"),result]
        row.add_child(l)
        if str(f.get("status","")) != "Played":
            _button(row, "Simulate", func(): _play_fixture(str(f.get("id",""))))
    _button(panel, "Back Home", func(): show_page("home"))

func _simulate_next() -> void:
    for f in GameState.fixtures:
        if str(f.get("status","")) != "Played":
            _play_fixture(str(f.get("id","")))
            return
    GameState.notification = "All sample fixtures have been played."
    status_label.text = GameState.notification

func _play_fixture(fixture_id: String) -> void:
    GameState.simulate_fixture(fixture_id)
    show_page("calendar")

func _show_squad() -> void:
    _heading("SQUAD MANAGEMENT", "Stable player IDs keep players linked to clubs across transfers.")
    var squad := GameState.get_squad()
    var panel := _panel("FIRST TEAM — %d PLAYERS" % squad.size())
    for p in squad:
        var row := HBoxContainer.new()
        panel.add_child(row)
        var l := Label.new()
        l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
        l.text = "%s • %s • OVR %d • Age %d • Value €%s" % [p.get("name",""),p.get("position",""),int(p.get("ovr",0)),int(p.get("age",0)),_money(int(p.get("value",0)))]
        row.add_child(l)
        _button(row, "Sell", func(): _sell_player(str(p.get("id",""))))
    _button(panel, "Back Home", func(): show_page("home"))

func _sell_player(player_id: String) -> void:
    GameState.sell_player(player_id)
    show_page("squad")

func _show_transfers() -> void:
    _heading("TRANSFER CENTRE", "Search by player name or position. Offers use the displayed estimated value and check the club budget.")
    var club := GameState.get_user_club()
    var panel := _panel("CLUB FINANCES")
    _text(panel, "%s • Transfer budget €%s" % [club.get("name","Unknown"),_money(int(club.get("budget",0)))])
    var row := HBoxContainer.new()
    panel.add_child(row)
    search_box = LineEdit.new()
    search_box.placeholder_text = "Search player or position (e.g. Haaland, RW, GK)"
    search_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    row.add_child(search_box)
    _button(row, "Search", func(): _render_targets(search_box.text), true)
    _render_targets("")

func _render_targets(query: String) -> void:
    var existing := content.get_node_or_null("TransferTargets")
    if existing:
        existing.queue_free()
    var outer := PanelContainer.new()
    outer.name = "TransferTargets"
    var style := StyleBoxFlat.new()
    style.bg_color = PANEL
    style.set_corner_radius_all(10)
    style.content_margin_left = 14
    style.content_margin_right = 14
    style.content_margin_top = 12
    style.content_margin_bottom = 12
    outer.add_theme_stylebox_override("panel", style)
    content.add_child(outer)
    var panel := VBoxContainer.new()
    panel.add_theme_constant_override("separation", 7)
    outer.add_child(panel)
    var heading := Label.new()
    heading.text = "AVAILABLE TARGETS"
    heading.add_theme_font_size_override("font_size", 17)
    heading.add_theme_color_override("font_color", ACCENT)
    panel.add_child(heading)
    var targets := GameState.get_targets(query)
    if targets.is_empty():
        _text(panel, "No players match this search.")
    for p in targets:
        var row := HBoxContainer.new()
        panel.add_child(row)
        var source := GameState.get_club(str(p.get("club_id","")))
        var l := Label.new()
        l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
        l.text = "%s • %s • OVR %d / POT %d • %s • €%s" % [p.get("name",""),p.get("position",""),int(p.get("ovr",0)),int(p.get("potential",0)),source.get("name","Unknown"),_money(int(p.get("value",0)))]
        row.add_child(l)
        _button(row, "Offer €%s" % _money(int(p.get("value",0))), func(): _buy_player(str(p.get("id",""))), true)
    if not GameState.transfer_history.is_empty():
        var history := _panel("RECENT TRANSFERS")
        for deal in GameState.transfer_history.slice(maxi(0, GameState.transfer_history.size() - 5), GameState.transfer_history.size()):
            _text(history, "%s: %s → %s • €%s" % [deal.get("player_name",""),deal.get("from",""),deal.get("to",""),_money(int(deal.get("fee",0)))])

func _buy_player(player_id: String) -> void:
    GameState.buy_player(player_id)
    show_page("transfers")

func _show_competitions() -> void:
    _heading("COMPETITION HUB", "Starter competition list and points table. Full international and continental tournament progression is planned, not implemented yet.")
    var panel := _panel("CONFIGURED LEAGUES")
    for league in GameState.leagues:
        _text(panel, "%s • %s • %d clubs configured" % [league.get("name",""),league.get("country",""),league.get("clubs",[]).size()])
    var table_panel := _panel("SAMPLE WORLD TABLE")
    var rows: Array = []
    for club in GameState.clubs:
        var stats: Dictionary = GameState.table.get(str(club.get("id","")), {})
        rows.append({"name":club.get("name",""),"played":int(stats.get("played",0)),"points":int(stats.get("points",0)),"gd":int(stats.get("gf",0))-int(stats.get("ga",0))})
    rows.sort_custom(func(a, b):
        if int(a.get("points",0)) == int(b.get("points",0)):
            return int(a.get("gd",0)) > int(b.get("gd",0))
        return int(a.get("points",0)) > int(b.get("points",0)))
    for i in range(rows.size()):
        var item: Dictionary = rows[i]
        _text(table_panel, "%d. %s — %d pts • %d played • GD %d" % [i + 1,item.get("name",""),int(item.get("points",0)),int(item.get("played",0)),int(item.get("gd",0))])

func _money(value: int) -> String:
    if value >= 1000000:
        return "%.1fM" % (float(value) / 1000000.0)
    if value >= 1000:
        return "%.0fK" % (float(value) / 1000.0)
    return str(value)
