extends Node
const SAVE_PATH := "user://blocklife_fc_save.json"
var players: Array = []
var clubs: Array = []
var fixtures: Array = []
var leagues: Array = []
var user_club_id := "blocklife"
var season := 2026
var current_date := "2026-08-01"
var career_mode := "Manager Career"
var manager_name := "Manager"
var created_player: Dictionary = {}
var table: Dictionary = {}
var transfer_history: Array = []
var notification := "Welcome to BLOCKLIFE FC."

func _ready() -> void:
    players = _read_array("res://data/players.json")
    clubs = _read_array("res://data/clubs.json")
    fixtures = _read_array("res://data/fixtures.json")
    leagues = _read_array("res://data/leagues.json")
    _reset_table()
    load_game()

func _read_array(path: String) -> Array:
    if not FileAccess.file_exists(path):
        push_warning("Missing data file: " + path)
        return []
    var parsed = JSON.parse_string(FileAccess.get_file_as_string(path))
    return parsed if parsed is Array else []

func _reset_table() -> void:
    table.clear()
    for club in clubs:
        table[str(club.get("id", ""))] = {"played":0,"won":0,"drawn":0,"lost":0,"gf":0,"ga":0,"points":0}

func get_club(club_id: String) -> Dictionary:
    for club in clubs:
        if str(club.get("id", "")) == club_id:
            return club
    return {}

func get_player(player_id: String) -> Dictionary:
    for player in players:
        if str(player.get("id", "")) == player_id:
            return player
    return {}

func get_user_club() -> Dictionary:
    return get_club(user_club_id)

func get_squad(club_id: String = "") -> Array:
    var target := user_club_id if club_id == "" else club_id
    var result: Array = []
    for player in players:
        if str(player.get("club_id", "")) == target:
            result.append(player)
    result.sort_custom(func(a, b): return int(a.get("ovr", 0)) > int(b.get("ovr", 0)))
    return result

func get_targets(query: String = "") -> Array:
    var result: Array = []
    var q := query.strip_edges().to_lower()
    for player in players:
        if str(player.get("club_id", "")) == user_club_id:
            continue
        if q != "" and not str(player.get("name", "")).to_lower().contains(q) and not str(player.get("position", "")).to_lower().contains(q):
            continue
        result.append(player)
    result.sort_custom(func(a, b): return int(a.get("ovr", 0)) > int(b.get("ovr", 0)))
    return result

func buy_player(player_id: String) -> bool:
    var player := get_player(player_id)
    var club := get_user_club()
    if player.is_empty() or club.is_empty():
        notification = "Transfer failed: record not found."
        return false
    if str(player.get("club_id", "")) == user_club_id:
        notification = "Player is already at your club."
        return false
    var fee := int(player.get("value", 0))
    if int(club.get("budget", 0)) < fee:
        notification = "Transfer rejected: insufficient budget."
        return false
    var previous_id := str(player.get("club_id", ""))
    var previous_club := get_club(previous_id)
    club["budget"] = int(club.get("budget", 0)) - fee
    previous_club["budget"] = int(previous_club.get("budget", 0)) + fee
    player["club_id"] = user_club_id
    transfer_history.append({"player_id":player_id,"player_name":player.get("name",""),"from":previous_club.get("name","Unknown"),"to":club.get("name","Unknown"),"fee":fee,"date":current_date})
    notification = "%s signed for %s." % [player.get("name", ""), club.get("name", "your club")]
    save_game()
    return true

func sell_player(player_id: String) -> bool:
    var player := get_player(player_id)
    var club := get_user_club()
    if player.is_empty() or str(player.get("club_id", "")) != user_club_id:
        notification = "Sale failed: player is not in your squad."
        return false
    var fee := int(float(player.get("value", 0)) * 0.9)
    var buyer: Dictionary = {}
    for candidate in clubs:
        if str(candidate.get("id", "")) != user_club_id and int(candidate.get("budget", 0)) >= fee:
            buyer = candidate
            break
    if buyer.is_empty():
        notification = "No club can afford this player."
        return false
    buyer["budget"] = int(buyer.get("budget", 0)) - fee
    club["budget"] = int(club.get("budget", 0)) + fee
    player["club_id"] = str(buyer.get("id", ""))
    transfer_history.append({"player_id":player_id,"player_name":player.get("name",""),"from":club.get("name","Your club"),"to":buyer.get("name","Unknown"),"fee":fee,"date":current_date})
    notification = "%s sold to %s." % [player.get("name", ""), buyer.get("name", "another club")]
    save_game()
    return true

func simulate_fixture(fixture_id: String) -> bool:
    for fixture in fixtures:
        if str(fixture.get("id", "")) != fixture_id:
            continue
        if str(fixture.get("status", "")) == "Played":
            notification = "Fixture already played."
            return false
        var home_id := str(fixture.get("home_club_id", ""))
        var away_id := str(fixture.get("away_club_id", ""))
        var hs := randi_range(0, 3)
        var aw := randi_range(0, 3)
        fixture["home_score"] = hs
        fixture["away_score"] = aw
        fixture["status"] = "Played"
        _record_result(home_id, away_id, hs, aw)
        notification = "%s %d - %d %s" % [get_club(home_id).get("name", home_id), hs, aw, get_club(away_id).get("name", away_id)]
        save_game()
        return true
    notification = "Fixture not found."
    return false

func _record_result(home_id: String, away_id: String, hs: int, aw: int) -> void:
    if not table.has(home_id) or not table.has(away_id):
        _reset_table()
    table[home_id]["played"] += 1
    table[away_id]["played"] += 1
    table[home_id]["gf"] += hs
    table[home_id]["ga"] += aw
    table[away_id]["gf"] += aw
    table[away_id]["ga"] += hs
    if hs > aw:
        table[home_id]["won"] += 1
        table[home_id]["points"] += 3
        table[away_id]["lost"] += 1
    elif aw > hs:
        table[away_id]["won"] += 1
        table[away_id]["points"] += 3
        table[home_id]["lost"] += 1
    else:
        table[home_id]["drawn"] += 1
        table[away_id]["drawn"] += 1
        table[home_id]["points"] += 1
        table[away_id]["points"] += 1

func save_game() -> void:
    var payload := {"version":1,"user_club_id":user_club_id,"season":season,"current_date":current_date,"career_mode":career_mode,"manager_name":manager_name,"created_player":created_player,"players":players,"clubs":clubs,"fixtures":fixtures,"table":table,"transfer_history":transfer_history}
    var file := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
    if file == null:
        notification = "Save failed. Check storage permissions."
        return
    file.store_string(JSON.stringify(payload, "\t"))
    file.close()
    notification = "Career saved."

func load_game() -> void:
    if not FileAccess.file_exists(SAVE_PATH):
        return
    var file := FileAccess.open(SAVE_PATH, FileAccess.READ)
    if file == null:
        return
    var payload = JSON.parse_string(file.get_as_text())
    file.close()
    if not payload is Dictionary:
        notification = "Save invalid; using starter data."
        return
    user_club_id = str(payload.get("user_club_id", user_club_id))
    season = int(payload.get("season", season))
    current_date = str(payload.get("current_date", current_date))
    career_mode = str(payload.get("career_mode", career_mode))
    manager_name = str(payload.get("manager_name", manager_name))
    created_player = payload.get("created_player", {})
    players = payload.get("players", players)
    clubs = payload.get("clubs", clubs)
    fixtures = payload.get("fixtures", fixtures)
    table = payload.get("table", table)
    transfer_history = payload.get("transfer_history", transfer_history)
    notification = "Saved career loaded."
