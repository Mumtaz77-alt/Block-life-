# Architecture

- `project.godot`: Godot settings and autoload.
- `scenes/main.tscn`: entry scene.
- `scripts/main.gd`: UI and navigation.
- `scripts/game_state.gd`: shared data, transactions, fixture simulation and save/load.
- `data/*.json`: editable databases.

Player and club IDs connect records. Transfers are immediate permanent deals at the listed estimated value. This is not yet a full negotiation system.
