# BLOCKLIFE FC — Godot 4 starter project

## Included and implemented
- Native Godot 4 project and GDScript main scene.
- Shared `GameState` autoload.
- JSON player, club, league and fixture databases.
- Home screen with Player Career and Manager Career entry points.
- Player Career starter profile and training progression.
- Squad screen with sale transactions.
- Transfer Centre search by name/position; permanent signings check budget and move player records between clubs.
- Fixture calendar with simulated results and a basic league points table.
- JSON save/load using `user://blocklife_fc_save.json`.

## Not yet implemented
- Playable 3D match, ball physics, animations, player switching or on-pitch AI.
- Negotiation rounds, loans, bonuses, contract clauses, scouting, youth generation, injuries, suspensions and realistic AI transfer planning.
- Complete real-world league schedules and qualification, UCL / Europa / Conference / World Cup / EURO tournament progression, season rollover, promotion or relegation.
- Verified live ratings, current contracts, wages, values or rosters. Starter real-player data is approximate.
- Official crests, kits, photos, or other licensed branding.
- Automated Godot runtime testing in this environment.

## Run
1. Install Godot 4.x (free).
2. Extract the ZIP.
3. In Godot Project Manager choose **Import** and select the extracted folder containing `project.godot`.
4. Open the project and press **F5**.

## Test checklist
1. Main menu loads and displays BLOCKLIFE United.
2. Select Player Career and train; OVR increases but does not exceed potential.
3. Open Calendar and simulate a fixture; the result changes to Played.
4. Open Competitions and confirm the points table updates after matches.
5. Open Squad and sell a player; the player changes clubs and budgets update.
6. Search `Haaland` in Transfer Centre and submit an offer if the budget allows.
7. Save, close, reopen, and Load to check persistence.

This is a first functional management-simulation milestone, not a complete football game. The 3D match engine is a later milestone.
